from configparser import ConfigParser

# config = ConfigParser()
# config.read("config.ini")
# print(config.get("basic info","browser"))

def readconfig(section,option):
    config = ConfigParser()
    config.read("..\\ConfigurationData\\conf.ini")
    return config.get(section,option)


