import time
from behave import *

from Utilities import readconfig
from features.pageobjects.LoginPage import LoginPage

@given(u'i navigate to mytripspreprod.travelsecurity.com')
def step_impl(context):
    context.reg = LoginPage(context.driver)
    context.driver.get("https://mytripspreprod.travelsecurity.com/")

@when(u'i clicked cookies button and provided username as "{username}"')
def step_impl(context,username):
     context.reg.setName(username)

@then(u'enter the password as "{password}"')
def step_impl(context,password):
    context.reg.setpassword(password)

@then(u'i click submit  button')
def step_impl(context):
    context.reg.submitform()
    time.sleep(5)

