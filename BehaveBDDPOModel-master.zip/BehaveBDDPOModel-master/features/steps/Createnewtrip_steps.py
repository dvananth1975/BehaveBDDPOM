import time
from behave import *

from Utilities import readconfig
from features.pageobjects.CreateTripPage import CreateTripPage

@then(u'Click New trip button')
def step_impl(context):
    context.reg.Clicknewtrip()
    time.sleep(5)

@then(u'enter Trip name as "{tripname}"')
def step_impl(context,tripname):
    context.reg.Tripname(tripname)
    time.sleep(5)

@then(u'enter Trip code as "{tripcode}"')
def step_impl(context,tripcode):
    context.reg.Tripcode(tripcode)
    time.sleep(5)

@then(u'Click Flight tab')
def step_impl(context):
        context.reg.Flight()

@then(u'select trip type as "{triptype}"')
def step_impl(context,triptype):
     time.sleep(5)
     context.reg.Triptype(triptype)
