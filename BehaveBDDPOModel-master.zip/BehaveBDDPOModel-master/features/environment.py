import time

from behave import *
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait


def before_scenario(context, driver):
    context.driver = webdriver.Chrome()
#
# def after_scenario(context, driver):
#     context.driver.quit()

def after_step(context, step):

    print()
