from features.pageobjects.BasePage import Basepage
from Utilities import readconfig
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

class LoginPage(Basepage):
    def __init__(self, driver):
        super().__init__(driver)

    def open(self,url):
        self.driver.get(url)

    def setName(self,username):
        #self.click("Acceptbutton_XPATH")
        self.click("//*[@id=\"onetrust-accept-btn-handler\"]")
        self.type("//*[@id=\"MainContent_LoginUser_txtUserName\"]", username)
    def setpassword(self,password):
        #self.type("password_XPATH", password)
        self.type("//*[@id=\"MainContent_LoginUser_txtPassword\"]", password)
    def submitform(self):
        # self.click("Submit_XPATH")
        self.click("//*[@id=\"MainContent_LoginUser_btnLogIn\"]")
