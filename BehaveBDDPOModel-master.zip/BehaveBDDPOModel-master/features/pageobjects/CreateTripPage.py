from features.pageobjects.BasePage import Basepage
from Utilities import readconfig
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

class CreateTripPage(Basepage):
    def __init__(self, driver):
        super().__init__(driver)


    def Clicknewtrip(self):
     self.click("//*[@id=\"MiddleBarControl_linkCreateNewTrip\"]")


    def Tripname(self, tripname):
     self.type("//*[@id=\"ctl00_MainContent_ucCreateTrip_ucTripInformation_txtTripName\"]", tripname)


    def Tripcode(self, tripcode):
        self.type("//*[@id=\"ctl00_MainContent_ucCreateTrip_ucTripInformation_134\"]", tripcode)

    def Flight(self):
     self.click("//*[@id=\"addFlightBtn\"]/a")

    def Triptype(self, triptype):
     self.type("//*[@id=\"MainContent_ucCreateTrip_ddFlightType\"]", triptype)
