import logging

from Utilities import readconfig
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from Utilities import LogUtil
from Utilities.LogUtil import Logger

#log = Logger(__name__,logging.INFO)
class Basepage:
    def __init__(self, driver):
        self.driver = driver
    def click(self,locator):
        self.driver.implicitly_wait(3)

        self.driver.find_element(By.XPATH,locator).click()
#        self.driver.find_element(By.XPATH, readconfig.readconfig("locators",locator)).click()
        #log.logger.info("Clicking Accept Button" + str(locator))

    def type(self,locator,value):
      self.driver.implicitly_wait(3)
      #self.driver.find_element(By.XPATH, readconfig.readconfig("locators",locator)).send_keys(value)

      self.driver.find_element(By.XPATH, locator).send_keys(value)
         # self.driver.find_element(By.XPATH, readconfig.readconfig("locators",locator)).send_keys(value)
     # log.logger.info("Typing username and password" +str(locator) + "Value is" +str(value))
      # def fillForm(self, username, password):
      #     self.type("username_XPATH", username)
      #     self.type("password_XPATH", password)
      #     self.click("Acceptbutton_XPATH")


